# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement music stopping
* [ ] Implement music fading
* [ ] Implement pause
* [ ] Add custom sound to the SEGA logo

