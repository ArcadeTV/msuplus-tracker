### SoundDriver
GEMS

| ID  | Track | Title          | Loop |
| :-- | :---: | :------------- | :--: |
| 4C  |  01   | STORY LINE     | yes  |
| 00  |  02   | TECHNO TUNE    | yes  |
| 24  |  03   | DANCE TUNE     | yes  |
| 0D  |  04   | TOXITOWN BLUES | yes  |
| 39  |  05   | DUELIN-DANCE   | yes  |
| 4E  |  06   | ICE BOSS TUNE  | yes  |
| 49  |  07   | DAN DA DANT DA |  no  |
| 0B  |  08   | MC ROCK PT 1   | yes  |
| 20  |  09   | MC ROCK PT 2   | yes  |
| 22  |  10   | FALL OVER TUNE |  no  |
| 23  |  11   | GAME OVER      |  no  |
| 36  |  12   | VIRGIN         |  no  |
| --  |  13   | SEGA Logo*     |  no  |
| --  |  14   | MSU Jingle*    |  no  |

* custom added tracks

### RAM Locations

| Address  |   Function   |
| :------- | :----------: |
|          |              |




























