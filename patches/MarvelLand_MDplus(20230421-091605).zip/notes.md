### SoundDriver
SMPS Z80

| ID 81-94 | Track | Title                       | Loop |
| :------- | :---: | :-------------------------- | ---- |
| 81       |  01   | Roller Coaster Stage        | yes  |
| 82       |  02   | World 1                     | yes  |
| 83       |  03   | Bonus Stage                 | no   |
| 84       |  04   | Dungeon Stage               | yes  |
| 85       |  05   | Escape                      | yes  |
| 86       |  06   | Boss Stage BGM              | yes  |
| 87       |  07   | Staff Roll                  | no   |
| 88       |  08   | Boss Stage Clear            | no   |
| 89       |  09   | Boss Stage Start            | yes  |
| 8A       |  10   | Round Start                 | no   |
| 8B       |  11   | Mole's Theme                | yes  |
| 8C       |  12   | Boss Stage Lost             | no   |
| 8D       |  13   | World Clear (Fairy's Theme) | yes  |
| 8E       |  14   | Round Clear                 | no   |
| 8F       |  15   | Unused (Player Down)        | no   |
| 90       |  16   | Mole Clear                  | no   |
| 91       |  17   | World 4                     | yes  |
| 92       |  18   | World 2                     | yes  |
| 93       |  19   | World 3                     | yes  |
| 94       |  20   | Door                        | no   |
| --       |  21   | MSU Jingle*                 | no   |
| --       |  22   | SEGA Logo*                  | no   |

*custom added tracks