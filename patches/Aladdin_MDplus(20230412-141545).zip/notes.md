## SoundDriver
GEMS 2.5

### Music map

| ID  | TRACK | TITLE             | LOOP |
| :-: | :---: | :---------------- | :--: |
| $0A |  01   | Ne Naw Tune       |  n   |
| $0F |  02   | Arab Rock 1       |  y   |
| $10 |  03   | Arab Rock 2       |  y   |
| $11 |  04   | Level Complete    |  n   |
| $12 |  05   | Boss Tune         |  y   |
| $14 |  06   | One Jump Ahead    |  y   |
| $16 |  07   | Turban Jazz       |  y   |
| $1A |  08   | A Whole New World |  y   |
| $1B |  09   | Friend Like Me    |  y   |
| $1D |  10   | Rug Ride          |  y   |
| $23 |  11   | Gloomy Tune       |  y   |
| $26 |  12   | Camel Jazz        |  y   |
| $32 |  13   | Bonus Tune        |  n   |
| $49 |  14   | Prince Ali        |  y   |
| $52 |  15   | Arabian Nights    |  y   |
| $54 |  16   | Storyline         |  y   |
| $55 |  17   | Drama             |  y   |
| $56 |  18   | Mushy One         |  n   |
| ??  |  19   | Continue          |  ?   |
| ??  |  20   | Game Over         |  ?   |
| --  |  21   | Sega*             |  n   |
| --  |  22   | MD+ Jingle*       |  n   |

*custom added tracks

---

### RAM Locations

| Address     | Function   |
| :---------- | :--------- |
| $00FFF158.b | Pause flag |

