### SoundDriver
SMPS 68K

| ID  | Track | Title                                          | Length | Loop |
| :-: | :---: | :--------------------------------------------- | :----- | ---- |
| 01  |   1   | Round 1-1 - Shooting Ristar                    |        | yes  |
| 02  |   2   | Round 3-1 - Busy Flare                         |        | yes  |
| 03  |   3   | Round 1-2 - Dancing Leaves                     |        | yes  |
| 04  |   4   | Battle Entry - Concentration                   |        | yes  |
| 05  |   5   | Round 4-1 - Pre-Song - Intension (First Bird)  |        | yes  |
| 06  |   6   | Round 4-1 - Pre-Song - Intension (Second Bird) |        | yes  |
| 07  |   7   | Round 4-1 - Pre-Song - Intension (Third Bird)  |        | yes  |
| 08  |   8   | Round 4-1 - Pre-Song - Intension (Fourth Bird) |        | yes  |
| 09  |   9   | Round 4-2 - On Parade                          |        | yes  |
| 0A  |  10   | Round 6-2 - Lock Up!!                          |        | yes  |
| 0B  |  11   | Round 5-1 - Ring Rink                          |        | yes  |
| 0C  |  12   | Round 2-2 - Break Silence                      |        | yes  |
| 0D  |  13   | Battle Theme - Crazy Kings                     |        | yes  |
| 0E  |  14   | Round 3-2 - Under Magma                        |        | yes  |
| 0F  |  15   | Round 2-1 - Splash Down!!                      |        | yes  |
| 10  |  16   | Round 5-2 - Ice Scream                         |        | yes  |
| 11  |  17   | Ending 2 - Next Cruise                         |        | no   |
| 12  |  18   | Round 4-1 - Du-Di-Da!!                         |        | yes  |
| 13  |  19   | Opening Theme 1 - Ebony Force                  |        | no   |
| 14  |  20   | Bonus Stage 2 - Ready... Go!!                  |        | yes  |
| 15  |  21   | Opening Theme 2 - Pray!! Pray!! Play!!         |        | yes  |
| 16  |  22   | Bonus Stage 1 - Formation Lap                  |        | yes  |
| 17  |  23   | Continue - Once More                           |        | no   |
| 18  |  24   | Theme of Kaiser - Greedy Game                  |        | yes  |
| 19  |  25   | Round 6-1 - Crying World                       |        | yes  |
| 1A  |  26   | Ending 1 - Star Humming                        |        | no   |
| 1B  |  27   | Round 4-1 - Pre-Song - Intension               |        | yes  |
| 1C  |  28   | Round Clear 2 - Beyond Space                   |        | no   |
| 1D  |  29   | Round Clear 1 - Let's Go!!                     |        | yes  |
| 1E  |  30   | Act Clear - Go Ahead                           |        | yes  |
| 1F  |  31   | Game Over                                      |        | no   |
| 20  |  32   | Cutscene - defeated Greedy                     |        | yes  |
| 21  |  33   | Round 4-1 - Du-Di-Da!! (Intro)                 |        | yes  |
| 8C  |  34   | Sega                                           |        | no   |
| --  |  35   | MSU Jingle*                                    |        | no   |

---

## AST

Collision Chaos Radio
https://www.youtube.com/watch?v=Okt8Pe5AUFQ

00:00 - Pray Pray Play
00:58 - Shooting Ristar
02:14 - Dancing Leaves
03:27 - Splash Down
04:18 - Break Silence
05:40 - Busy Flare
07:04 - Under Magma
08:00 - DuDiDa (variation 1)
08:17 - DuDiDa (variation 2)
08:34 - DuDiDa
09:08 - On Parade
10:59 - Ring Rink
12:00 - Ice Scream
13:15 - Crying World
14:38 - Game Over
14:45 - Ready Go
15:20 - Crazy Kings
16:18 - Ending