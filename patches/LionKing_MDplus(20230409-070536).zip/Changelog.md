## Changelog 

### 2023-04-09 06:58:41
* added pause/resume music

### 2023-04-09 06:41:33
* added SEGA logo sound

### 2023-04-01 23:14:52
* initial commit