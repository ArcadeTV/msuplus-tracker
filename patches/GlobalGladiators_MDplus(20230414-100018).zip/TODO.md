# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement music stopping
* [x] Implement pause
* [ ] Implement music fading
* [ ] Add custom sound to the SEGA logo

### nice to have

* [x] Add custom sound to the Virgin logo
