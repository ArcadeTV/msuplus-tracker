# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [ ] Implement pause (originally not stopping)
* [ ] Implement music stopping
* [ ] Implement music fading
* [ ] Add custom sound to the SEGA logo

### known issues

* not perfect due to messed up stack when calling subroutines from bypassed locations
* hangs in tournament mode (could be an emulation issue, as it also happens on original rom)
* restarting menu music while navigating