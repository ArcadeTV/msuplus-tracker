# mdplus-aladdin

* [x] SRC available at https://github.com/ArcadeTV/mdplus-aladdin
* [x] Please see the [Changelog](https://github.com/ArcadeTV/mdplus-aladdin/blob/master/Changelog.md)
* [x] Please see unfinished [Todos](https://github.com/ArcadeTV/mdplus-aladdin/blob/master/TODO.md)
* [x] Report any issues [here](https://github.com/ArcadeTV/mdplus-aladdin/issues)

```
 _____               _     _____ _____ 
|  _  |___ ___ ___ _| |___|_   _|  |  |
|     |  _|  _| .'| . | -_| | | |  |  |
|__|__|_| |___|__,|___|___| |_|  \___/ 
                             

Title:         Aladdin - MD+ enhanced
System:        SEGA GENESIS / MEGA DRIVE

System:        SEGA GENESIS / MEGA DRIVE
               
Compatibility: NTSC Region (US, JP) [60Hz]
               Works on real hardware 
               - with Terraonion MegaSD
               - with Krikzz MEGA Everdrive PRO
               Works in emulation
               - with RetroArch / Genesis-Plus-GX core

Category:      Romhack|Music

SourceROMs:    Aladdin (USA).md [No-Intro]
CRC32:         ED427EA9

Soundpacks:    Maintained by Relikk on the zeldix forums.

Thanks:        Infinest
               Krikzz (everdrive creator)
               Jeroen Visser for md-driver-signatures
               Relikk for maintaining all the soundPacks
```

### HOW TO USE

1. Obtain source ROM.
2. Use the BPS patch file from the current release to patch your ROM. I recommend FLIPS. 
   -> https://dl.smwcentral.net/11474/floating.zip
3. Download the SoundPack and extract everything to the same folder where your patched ROM is located. Rename the cue file to the ROM's base-filename (eg. game.md and game.cue)

### FAQ

> * Game does not boot
>> When using RetroArch, make sure you have the correct CD bios files. Your ROM and .cue files must be in the same folder and have identical base-filenames. Other hardware or emulators other than specified are not currently supported.

> * Game has no music
>> Most likely it's a problem with the .cue file. Open it with a text-editor and see if there's an issue with paths or filenames. Tools like CD-Mage will also report issues with the .cue

> * Can you make a patch for game [insert game name here]
>> Nope, but I'd like your feedback on this one.

> * I want other music to be played in the game
>> No problemo. Just add your own WAVE/44.1KHz/16bit and .cue files.

> * I don't like your MD+ intro, can it be removed?
>> Sorry to hear that. You can insert the original M68K vectors for "reset", "h-int" and "v-int" from your source ROM into the patched one to get rid of it.