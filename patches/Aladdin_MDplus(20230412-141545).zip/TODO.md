# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement pause
* [x] Implement music stopping
* [ ] Implement music fading
* [x] Add custom sound to the SEGA logo

### nice to have

* [ ] Find arranged music from Disney
