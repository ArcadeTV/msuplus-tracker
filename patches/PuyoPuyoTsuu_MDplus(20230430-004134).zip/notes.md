## SoundDriver
Compile custom

### Sound map

| Track | ID  | Title                | Loop |
| :---: | :-: | :------------------- | :--: |
|  01   | 01  | Game Over            |  -   |
|  02   | 02  | Victory              |  -   |
|  03   | 03  | Win                  |  -   |
|  04   | 04  | Main Menu            |  Y   |
|  05   | 05  | How to Play          |  Y   |
|  06   | 06  | Opening Theme        |  Y   |
|  07   | 07  | Ending C             |  Y   |
|  08   | 08  | Last Area            |  Y   |
|  09   | 09  | Mode Select          |  Y   |
|  10   | 0A  | Area B               |  Y   |
|  11   | 0B  | Area A               |  Y   |
|  12   | 0C  | Area C               |  Y   |
|  13   | 0D  | Warning              |  -   |
|  14   | 0E  | Ending B             |  Y   |
|  15   | 0F  | Ending A             |  Y   |
|  16   | 61  | Death                |  -   |
|  17   | 48  | All Clear            |  -   |
|  18   | --  | SEGA Logo*           |  -   |
|  19   | --  | Sound Driver Jingle* |  -   |

*custom added tracks

