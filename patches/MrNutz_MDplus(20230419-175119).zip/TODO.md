# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement pause
* [x] Implement music stopping
* [x] Implement music fading
* [x] Add custom sound to the SEGA logo

### nice to have

* [ ] Add additional music that was absent in the MD version
