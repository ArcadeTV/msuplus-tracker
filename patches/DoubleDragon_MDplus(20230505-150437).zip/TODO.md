# TODOs

### mandatory tasks

* [X] Mute Chipsound
* [X] Play all music from CD
* [X] Implement music stopping
* [ ] Implement music fading
* [ ] Implement pause/resume
* [ ] Add custom sound to the SEGA logo

### nice to have

 