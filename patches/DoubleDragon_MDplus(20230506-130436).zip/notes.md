## SoundDriver
Sound Images 1.0

### Sound map

| Track | ID  | Title                                  | Sound Test           | Loop | Bank |
| :---: | :-: | :------------------------------------- | :------------------- | :--: | :--: |
|  01   | 01  | Mission Complete                       | BONUS                |  -   |  2   |
|  02   | 02  | Arrival of the Black Warriors (Slums)  | LEVEL 1              |  Y   |  2   |
|  03   | 03  | Riot (Industrial Area)                 | LEVEL 2              |  Y   |  2   |
|  04   | 04  | Woods                                  | LEVEL 3              |  Y   |  2   |
|  05   | 05  | Old Nemesis Willy (Enemy Headquarters) | LEVEL 4              |  Y   |  2   |
|  06   | 06  | The Entrance of Abobo the Giant        | GUARDIAN             |  Y   |  2   |
|  07   | 02  | Double Dragon (Opening Theme)          | FRONTEND             |  Y   |  1   |
|  08   | 03  | Reunion with Marian (Ending Theme)     | VICTORY              |  -   |  1   |
|  09   | --  | SEGA Logo*                             | SEGA Logo*           |  -   |  -   |
|  10   | --  | Sound Driver Jingle*                   | Sound Driver Jingle* |  -   |  -   |

*custom added tracks


### RAM

| Address | Function         |
| :------ | :--------------- |
| $FF024E | Sound Bank (1/2) |


### Cheats

https://gamehacking.org/game/15013

Std:
002C70:0364

GG:
NT0A-AGDT