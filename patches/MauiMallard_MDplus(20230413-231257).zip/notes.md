## SoundDriver
GEMS 2.8

### Music map

| ID  | TRACK | TITLE                           | LOOP |
| :-: | :---: | :------------------------------ | :--: |
| 00  |  01   | Title Screen                    | yes  |
| 25  |  02   | Stage 1: The Mojo Mansion       | yes  |
| 1A  |  03   | Stage 2: Ninja Training Grounds | yes  |
| 24  |  04   | Stage 3: Mudrake Mayhem         | yes  |
| 28  |  05   | Stage 4: The Sacrifice of Maui  | yes  |
| 2A  |  06   | Stage 5: The Test of Duckhood   | yes  |
| 2C  |  07   | Stage 6: The Flying Duckman     | yes  |
| 2E  |  08   | Stage 7: The Realm of the Dead  | yes  |
| 57  |  09   | Stage 8: Mojo Stronghold        | yes  |
| 54  |  10   | Boss Battle                     | yes  |
| 53  |  11   | Level Complete                  |  no  |
| 99  |  12   | Ending Part 1                   | yes  |
| 95  |  13   | Ending Part 2                   | yes  |
| 56  |  14   | Continue?                       | yes  |
| 97  |  15   | Game Over                       |  no  |
| --  |  21   | Sega*                           |  no  |
| --  |  22   | MD+ Jingle*                     |  no  |

*custom added tracks

---

### RAM Locations

| Address | Function |
| :------ | :------- |
|         |          |

