## SoundDriver
GEMS 2.8

### Music map

| ID  | TRACK | TITLE                           | LOOP |
| :-: | :---: | :------------------------------ | :--: |
| 4C  |  01   | Konami Logo                     |  no  |
| 05  |  02   | Weird Kids on the Block (Title) | yes  |
| 2C  |  03   | Zombie Panic                    | yes  |
| 17  |  04   | Stage Clear                     |  no  |
| 02  |  05   | Evening of the Undead           | yes  |
| 2A  |  06   | No Assembly Required            | yes  |
| 28  |  07   | Pyramid of Fear                 | yes  |
| 2E  |  08   | Mars Needs Cheerleaders         | yes  |
| 2F  |  09   | Curse of the Tongue             | yes  |
| 06  |  10   | Mushroom Men                    | yes  |
| 2D  |  11   | Boss Battle                     | yes  |
| 03  |  12   | Titanic Toddler                 | yes  |
| 12  |  13   | Pandora's Box                   |  no  |
| 18  |  14   | Player Death                    |  no  |
| 01  |  --   | Unused (Sound Code 01)          | yes  |
| --  |  15   | Sega*                           |  no  |
| --  |  16   | MD+ Jingle*                     |  no  |

*custom added tracks

---

### RAM Locations

| Address | Function |
| :------ | :------- |
|         |          |
