## SoundDriver
Compile custom

### Sound map

| Track | ID  | Title                           | Loop |
| :---: | :-: | :------------------------------ | :--: |
|  01   | 01  | Final of Puyo Puyo              |  Y   |
|  02   | 02  | Theme of Puyo Puyo              |  Y   |
|  03   | 03  | Baroque of Puyo Puyo            |  Y   |
|  04   | 04  | Cooking of Puyo Puyo            |  Y   |
|  05   | 05  | Morning of Puyo Puyo            |  Y   |
|  06   | 06  | Toy of Puyo Puyo                |  Y   |
|  07   | 07  | Sorrow of Puyo Puyo             |  -   |
|  08   | 08  | Sticker of Puyo Puyo            |  Y   |
|  09   | 09  | Clear                           |  -   |
|  10   | 0A  | Sunset of Puyo Puyo             |  Y   |
|  11   | 0B  | Rejection of Puyo Puyo (unused) |  Y   |
|  12   | 0C  | Memories of Puyo Puyo           |  Y   |
|  13   | 0D  | Memories ~Harpy Version~        |  Y   |
|  14   | 0E  | Warning of Puyo Puyo            |  Y   |
|  15   | 0F  | Theme of Satan                  |  Y   |
|  16   | 10  | Brave of Puyo Puyo              |  Y   |
|  17   | 11  | Ondo of Puyo Puyo               |  Y   |
|  18   | 12  | Victory of Puyo Puyo            |  -   |
|  19   | --  | SEGA Logo*                      |  -   |
|  20   | --  | Sound Driver Jingle*            |  -   |

*custom added tracks

