### SoundDriver
YMOIMO (Cube/Masaru Suzuki)

| ID  | Track | Title                                              | Loop |
| :-: | :---: | :------------------------------------------------- | :--: |
| 0D  |  01   | Jack'n (Title Theme)                               |  no  |
| 0B  |  02   | Round Start                                        |  no  |
| 01  |  03   | Insector X ~ Theme of KAIT (Round 1 - Desert Area) | yes  |
| 02  |  04   | Oriental Fear (Round 1 - In the Pyramid)           | yes  |
| 03  |  05   | Skylight Tune (Round 2 - Plateau Area)             | yes  |
| 04  |  06   | Grooving Diver (Round 3 - City Area)               | yes  |
| 05  |  07   | Silent Mad Service (Round 3 - In the Sewers)       | yes  |
| 06  |  08   | Tropic Gym (Round 4 - Jungle Area)                 | yes  |
| 07  |  09   | Damp Hall (Round 4 - In the Cave)                  | yes  |
| 08  |  10   | Party in Their Nest (Round 5 - Their Empire)       | yes  |
| 09  |  11   | Last Battalion (Boss Theme)                        | yes  |
| 0A  |  12   | Farewell Insector (Ending Theme)                   | yes  |
| 0C  |  13   | Game Over                                          |  no  |
| --  |  14   | SEGA Logo*                                         |  no  |
| --  |  15   | MSU Jingle*                                        |  no  |

*custom added tracks


### ROM Locations

| Address | Function | original instruction   | Bytes |
| :------ | :------- | ---------------------- | :---: |
|         |          |                        |       |


### RAM Locations

| Address   | Function   |
| :-------- | :--------- |
| $FF9722.w | Pause flag |

