### SoundDriver
YMOIMO (Cube/Masaru Suzuki)

| ID  | Track | Title                      | Loop |
| :-: | :---: | :------------------------- | :--: |
| 00  |  --   | -Pause-On/Off-             |  --  |
| FF  |  --   | -Stop-                     |  --  |
| FE  |  --   | -Stop-                     |  --  |
| FD  |  --   | -FadeOut-                  |  --  |
| --- | ----  | -------------------------- | ---- |
| 01  |  01   | Ready                      |  no  |
| 09  |  02   | Main Theme                 | yes  |
| 04  |  03   | Goal In                    |  no  |
| 0A  |  04   | Boss Theme                 | yes  |
| 03  |  05   | Secret Room                | yes  |
| 15  |  06   | Ready (Arkanoid)           |  no  |
| 0D  |  07   | Cosmic Airway (Darius)     | yes  |
| 0E  |  08   | Boss Theme (Darius)        | yes  |
| 06  |  09   | Fake Ending                |  no  |
| 19  |  10   | Main Theme (Bubble Bobble) | yes  |
| 1A  |  11   | Dragon (Bubble Bobble)     | yes  |
| 07  |  12   | Ending Theme               |  no  |
| 05  |  13   | Game Over                  |  no  |
| 78  |  14   | SEGA Logo*                 |  no  |
| --  |  15   | MSU Jingle*                |  no  |

*custom added tracks

02 - Unused?
08,0B,0C,0F,10 - Ready (alt)



### ROM Locations

| Address | Function | original instruction   | Bytes |
| :------ | :------- | ---------------------- | :---: |
| $8226   | Hurry Up | move.w  #0,($FFE032).w |   6   |
|         |          |                        |       |

### RAM Locations

| Address | Function   |
| :------ | :--------- |
| $FFE87E | game timer |

