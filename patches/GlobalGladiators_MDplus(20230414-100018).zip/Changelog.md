## Changelog 

### 2023-04-14 08:49:50
* added stop instruction
* removed vram-clr routine after intro to fix hanging

### 2023-04-01 23:14:52
* initial commit