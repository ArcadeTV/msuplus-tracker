## SoundDriver
Westone/Shinichi Sakamoto

### Sound map

| Track | ID  | Title                      | Loop |
| :---: | :-: | :------------------------- | :--: |
|  01   | 00  | Overture                   | 0:33 |
|  02   | 01  | Over the Clouds            | 0:27 |
|  03   | 02  | Arabesque Court in Dream   | 0:40 |
|  04   | 03  | Main Theme                 | 0:39 |
|  05   | 04  | Stream Sanctuary           | 0:42 |
|  06   | 05  | Birth of Pepelogoo         |  -   |
|  07   | 06  | Lamp de Godjarre           | 0:51 |
|  08   | 07  | Long Distance              | 0:44 |
|  09   | 08  | Labyrinth on the Sky       | 0:37 |
|  10   | 09  | Kool Dude                  | 1:43 |
|  11   | 0A  | Premonition                |  -   |
|  12   | 0B  | Kingdom of Rapadagna       | 0:52 |
|  13   | 0C  | Try the Trial              | 0:31 |
|  14   | 0D  | Volcanic Cave              | 0:37 |
|  15   | 0E  | Heart of Icegrave          | 0:54 |
|  16   | 0F  | Head Banger                | 0:18 |
|  17   | 10  | Malevolent Deity           | 0:42 |
|  18   | 11  | Finale Part 1              |  -   |
|  19   | 12  | A Cradle Song of Pepelogoo | 0:05 |
|  20   | 13  | Tales From Monster World   | 0:16 |
|  21   | 15  | Finale Part 2              |  -   |
|  22   | 16  | Acension to Heaven         |  -   |
|  23   | 17  | Conquers the Dungeon       |  -   |
|  24   | 22  | Cathedral                  | 0:08 |
|  25   | 23  | Fade Into Darkside         | 0:30 |
|  26   | 24  | Rebirth                    | 0:07 |
|  27   | 49  | Carpet                     | 0:34 |
|  28   | 4D  | Death of Pepelogoo         |  -   |
|  29   | 4E  | Spirits                    | 0:07 |
|  30   | 52  | Finale Part 3              | 0:09 |
|  31   | --  | SEGA                       |  -   |
|  32   | --  | MD+ Jingle                 |  -   |

*custom added tracks
