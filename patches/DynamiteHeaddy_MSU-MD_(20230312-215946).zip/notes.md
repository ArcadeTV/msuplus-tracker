### SoundDriver
SMPS M68K Treasure

| ID  | Track | Title                                  | Length | Loop |
| :-- | :---- | :------------------------------------- | :----- | ---- |
| 01  | 01    | Headdy the Hero                        |        |      |
| 02  | 42    | Crosswalk of Love (Short Version)      |        |      |
| 03  | 18    | Opening Theme                          |        |      |
| 04  | 05    | Escape Hero                            |        |      |
| 05  | 36    | Mystery Spot                           |        |      |
| 06  | 39    | Escape Hero (Short Version)*           |        |      |
| 07  | 30    | That's the Way the Boss is Killed      |        |      |
| 08  | 12    | Danzen Dungeon                         |        |      |
| 09  | 09    | South Town's Theme                     |        |      |
| 0A  | 14    | Maruyama Appears                       |        |      |
| 0B  | 31    | Nutcracker                             |        |      |
| 0C  | 06    | Tower of Puppet                        |        |      |
| 0D  | 08    | Sky High                               |        |      |
| 0E  | 27    | A Man of Sun                           |        |      |
| 0F  | 19    | I Sing                                 |        |      |
| 10  | 15    | Hustle Maruyama (Part 1)               |        |      |
| 11  | 38    | Hustle Maruyama (Part 2)*              |        |      |
| 12  | 24    | Hattari is Here                        |        |      |
| 13  | 29    | Kejime (Kejime 1)                      |        |      |
| 14  | 21    | Tonight's a Jazzy Night                |        |      |
| 15  | 25    | Dark Demon's Song                      |        |      |
| 16  | 28    | Good for You!!                         |        |      |
| 17  | 07    | North Town's Theme                     |        |      |
| 18  | 17    | Funny Angry                            |        |      |
| 19  | 11    | Paradise                               |        |      |
| 1A  | 35    | Why, Figgy                             |        |      |
| 1B  | 41    | Next Stage*                            |        |      |
| 1C  | 20    | Walk Towards Me                        |        |      |
| 1D  | 40    | Headdy! Headdy!*                       |        |      |
| 1E  | 43    | Game Over*                             |        |      |
| 1F  | 44    | Silence*                               |        |      |
| 20  | 16    | It's Good if it Ends Happily, Isn't It |        |      |
| 21  | 10    | Crosswalk of Love                      |        |      |
| 22  | 26    | Ballad for You                         |        |      |
| 23  | 02    | Geisha Robot (Carmen)                  |        |      |
| 24  | 23    | Ohnami Konami                          |        |      |
| 25  | 04    | Schumacher Fly                         |        |      |
| 26  | 13    | You're Izayoi                          |        |      |
| 27  | 32    | Night of Dial Q2                       |        |      |
| 28  | 33    | Kejime (Kejime 2)                      |        |      |
| 29  | 34    | Good Job, Headdy                       |        |      |
| 2A  | 22    | I Love Goldie Hawn                     |        |      |
| --  | 45    | SEGA / Treasure Logo                   |        |      |

* custom added tracks


### SoundTrack CD Track Order:

01. Headdy the Hero (Vocal Arrange Version).wav
02. Carmen (Headdy Version).wav
03. Headdy The Hero.wav
04. Schumacher Flight.wav
05. Escape Hero.wav
06. Tower of Puppet.wav
07. North Town's Theme.wav
08. Sky High.wav
09. South Town's Theme.wav
10. Crossing of Love.wav
11. Paradise.wav
12. Danzen Dungeon.wav
13. You're Izayoi.wav
14. Maruyama Appears.wav
15. Hustle Maruyama.wav
16. It's Good if it Ends Happily.wav
17. Funny Angry.wav
18. Opening Theme.wav
19. I Sing.wav
20. Walk Towards Me.wav
21. Tonight's a Jazzy Night.wav
22. I Love Goldie Hawn.wav
23. Ohnami Konami.wav
24. Hattari is Here.wav
25. Dark Demon's Song.wav
26. Ballard for You.wav
27. A Man of Sun.wav
28. Good for You!!.wav
29. Kejime (Kejime 1).wav
30. That's the Way the Boss is Killed.wav
31. Nutcracker.wav
32. Night of Dial Q2.wav
33. Kejime (Kejime 2).wav
34. Good Job, Headdy.wav
35. Why, Figgy.wav
36. Mystery Spot.wav
37. Voice.wav


### Sound Test


### RAM Locations

* $FFE806.w: Pause (0000/0001)
* $FFE80A.b: Input Data
