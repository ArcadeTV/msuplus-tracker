# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [ ] Implement pause
* [x] Implement music stopping
* [ ] Implement music fading
* [ ] Add custom sound to the SEGA logo

### nice to have

* [ ] Find missing arranged music: mushroom men, players death
