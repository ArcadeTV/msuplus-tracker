### SoundDriver
Krisalis

| ID  | Track | Bank | Title                         | Loop |
| :-- | :---: | :--: | :---------------------------- | :--: |
| 01  |  --   |  --  | Stop Music                    |  --  |
| ?   |  01   |  00  | Simba Confronts Scar          | yes  |
| 02  |  02   |  00  | I Just Can't Wait To Be King  | yes  |
| 02  |  03   |  01  | King Pride Rock               | yes  |
| 19  |  04   |  01  | Under the Stars               | yes  |
| 28  |  05   |  00  | Hakuna Matata                 | yes  |
| 37  |  06   |  01  | Hoo Hah Remix                 | yes  |
| 3D  |  07   |  00  | Can You Feel the Love Tonight | yes  |
| 47  |  08   |  01  | Circle Remix                  | yes  |
| 49  |  09   |  00  | Circle of Life                | yes  |
| 53  |  10   |  00  | Be Prepared                   | yes  |
| 53  |  11   |  01  | Finale                        |  no  |
| 86  |  12   |  00  | Hoo Hah                       | yes  |
| 89  |  13   |  00  | This Land                     | yes  |
| 91  |  14   |  00  | To Die For                    | yes  |
| 9E  |  15   |  00  | Bonus Stage 2                 | yes  |
| AE  |  16   |  01  | Death Tag                     |  no  |
| AF  |  17   |  01  | King Tag                      |  no  |
| --  |  18   |  --  | SEGA Logo*                    |  no  |
| --  |  19   |  --  | MSU Jingle*                   |  no  |

* custom added tracks

### RAM Locations

| Address |  Function  |
| :------ | :--------: |
| FF000C  | pause flag |

