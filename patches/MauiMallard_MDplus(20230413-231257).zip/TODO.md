# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement pause (originally not stopping)
* [x] Implement music stopping
* [ ] Implement music fading
* [ ] Add custom sound to the SEGA logo

