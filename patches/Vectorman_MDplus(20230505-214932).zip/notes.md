### SoundDriver
GEMS 2.8

| ID  | Track | Title                                             | Loop |
| :-- | :---: | :------------------------------------------------ | :--: |
| 00  |  --   | -Silence-                                         |  --  |
| 01  |  01   | Title Theme                                       |  no  |
| 02  |  02   | Day 1 Terraport, Day 6 Bamboo Mill                | yes  |
| 03  |  03   | Day 5 Arctic Ridge, Day 9 Hydroponic Lab          | yes  |
| 04  |  04   | Day 7 Rock 'n' Roller, Day 14 Underground Vault   | yes  |
| 05  |  05   | Information, Day 8 Death Alley                    | yes  |
| 06  |  06   | Options                                           | yes  |
| 07  |  07   | Day 3 Tidal Surge, Day 12 Nightscape, Bonus Round | yes  |
| 08  |  08   | Day 11 Stayin' Alive                              | yes  |
| 09  |  09   | Stage Clear                                       |  no  |
| 0A  |  10   | Introduction                                      | yes  |
| 0B  |  11   | Day 16 Twist and Shout                            | yes  |
| 0C  |  12   | Day 2 Metalhead                                   | yes  |
| 0D  |  13   | Ending Theme                                      |  no  |
| 0E  |  14   | Day 10 Superstructure, Day 13 Dark Ruins          | yes  |
| 0F  |  15   | Day 4 Absolute Zero, Day 15 Worldlink Center      | yes  |
| --  |  16   | SEGA Logo*                                        |  no  |
| --  |  17   | MSU Jingle*                                       |  no  |

* custom added tracks

### RAM Locations

| Address | Function             |
| :------ | :------------------- |
|         |                      |

