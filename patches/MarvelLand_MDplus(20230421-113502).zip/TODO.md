# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement pause
* [x] Implement music stopping
* [x] Implement music fading

### nice to have

* [x] Add custom sound to the NAMCO logo
