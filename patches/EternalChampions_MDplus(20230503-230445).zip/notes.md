## SoundDriver
GEMS

### Music map

| ID  | TRACK | TITLE                    | LOOP |
| :-: | :---: | :----------------------- | :--: |
| 00  |  01   | Blade's Stage            |  Y   |
| 01  |  02   | Eternal Champion's Stage |  Y   |
| 02  |  03   | Shadow's Stage           |  Y   |
| 03  |  04   | RAX's Stage              |  Y   |
| 04  |  05   | Xavier's Stage           |  Y   |
| 05  |  06   | Jetta's Stage            |  Y   |
| 06  |  07   | Slash's Stage            |  Y   |
| 07  |  08   | Battle Room              |  Y   |
| 08  |  09   | Midknight's Stage        |  Y   |
| 09  |  10   | Menu Theme               |  Y   |
| 0A  |  11   | Larcen's Stage           |  Y   |
| 0B  |  12   | Trident's Stage          |  Y   |
| 0C  |  13   | Main Theme               |  Y   |
| 0D  |  14   | Bad Ending               |  Y   |
| 0E  |  15   | Character Bios           |  Y   |
| 0F  |  16   | Tournament Results       |  Y   |
| --  |  17   | Sega*                    |  -   |
| --  |  18   | MD+ Jingle*              |  -   |

*custom added tracks

---

### RAM Locations

| Address | Function |
| :------ | :------- |
|         |          |

