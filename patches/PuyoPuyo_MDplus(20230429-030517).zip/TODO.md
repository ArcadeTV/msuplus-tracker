# TODOs

### mandatory tasks

* [x] Mute Chipsound
* [x] Play all music from CD
* [x] Implement music stopping
* [x] Implement music fading
* [x] Implement pause and resume
* [x] Add custom sound to the SEGA logo

### nice to have
* [x] Make a modern soundPack from all the latest Puyo soundtracks
 