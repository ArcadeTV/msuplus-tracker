### SoundDriver
TecnoSoft 1.31


### Z80 CommandsTable

| Command        | Value |
| :------------- | :---: |
| LoadBGM2       |  01   |
| LoadSFX        |  02   |
| FadeOutBGM     |  03   |
| u_StopSFX      |  04   |
| PlayVoice      |  05   |
| ResetCommand   |  06   |
| u_FetchOffset  |  07   |
| u_FetchOffset2 |  08   |
| LoadBGM        |  09   |
| LoadSoundBank  |  0A   |
| PlayVoice2     |  0B   |
| PauseMusic     |  0C   |
| PlayVoice3     |  0D   |

---

### RAM

| Address |       Value       |
| :------ | :---------------: |
| $FFF300 | pause 0:on, 1:off |

---

### Sound Test

| Index |  ID   |  CD   |  BANK   | Song             | Alt Name                                         |
| :---: | :---: | :---: | :-----: | :--------------- | :----------------------------------------------- |
|  00   |  00   |  01   |  78000  | STAGE-1(1)       | Fighting Back (Strite Part 1)                    |
|  01   |  01   |  02   |  78000  | STAGE-2(1)       | Space Walk (Ruin Part 1)                         |
|  02   |  02   |  03   |  78000  | STAGE-3(1)       | The Sky Line (Air Raid Part 1)                   |
|  03   |  03   |  04   |  78000  | STAGE-4(1)       | Sand Hell (Daser Part 1)                         |
|  04   |  04   |  05   |  78000  | STAGE-5          | Battle Ship (Space Cruiser Part 1)               |
|  05   |  05   |  06   |  78000  | STAGE-6          | Great Sea Power (Volbados)                       |
|  06   |  06   |  07   |  78000  | STAGE-7          | Sea Of Flame (Desvio)                            |
|  07   |  07   |  08   |  78000  | STAGE-8          | Metal Squad (Bio Base)                           |
|  08   |  08   |  09   |  78000  | STAGE-9          | Down Right Attack (Wall)                         |
|  09   |  09   |  10   |  78000  | STAGE-10         | The Danger Zone (Versus)                         |
|  10   |  0A   |  11   |  78000  | STAGE-1 (2)      | What (Strite Part 2)                             |
|  11   |  0B   |  12   |  78000  | STAGE-2 (2)      | Danger!! Danger!! (Ruin Part 2)                  |
|  12   |  0C   |  13   |  78000  | STAGE-3 (2)      | Air Raid (Air Raid Part 2)                       |
|  13   |  0D   |  14   |  78000  | STAGE-4 (2)      | Where! (Daser Part 2)                            |
|  14   |  0E   |  15   |  78000  | STAGE-5(DOCKING) | Neo Weapon (Space Cruiser Part 2 - Docking)      |
| ..... | ..... | ..... | ....... | ...............  | ................................................ |
|  15   |  0F   |  16   |  80000  | OPENING          | Lightning Strikes Again (Opening Theme)          |
|  16   |  10   |  17   |  80000  | COURSE SELECT    | Don't Go Off (Course Select)                     |
|  17   |  11   |  18   |  80000  | BOSS-1           | Evil Destroyer (Gargoyle Diver)                  |
|  18   |  12   |  19   |  80000  | BOSS-2           | Attack Sharply (Hell Arm)                        |
|  19   |  13   |  20   |  80000  | BOSS-3           | Simmer Down (Ratt Carry)                         |
|  20   |  14   |  21   |  80000  | BOSS-4           | Strike Out (Fomalhaut)                           |
|  21   |  15   |  22   |  80000  | BOSS-5           | Stranger (Space Cruiser Boss)                    |
|  22   |  16   |  23   |  80000  | BOSS-6           | The Breaker (Volbados Boss)                      |
|  23   |  17   |  24   |  80000  | BOSS-7           | Rancor (Desvio Boss)                             |
|  24   |  18   |  25   |  80000  | BOSS-8           | Phantom (Bio Base Boss)                          |
|  25   |  19   |  26   |  80000  | BOSS-9           | Recalcitrance (Wall Boss)                        |
|  26   |  1A   |  27   |  80000  | BOSS-10          | War Like Requiem (Versus Boss)                   |
|  27   |  1B   |  28   |  80000  | CONFIGURATION    | Tan Tan Ta Ta Ta Tan (Configuration)             |
|  28   |  1C   |  29   |  80000  | GAME OVER        | Dead End (Game Over)                             |
|  29   |  1D   |  30   |  80000  | CONTINUE         | Count Down (Continue)                            |
|  30   |  1E   |  31   |  80000  | RANKING(ACE)     | Because You're The Number One (Ace Ranking)      |
|  31   |  1F   |  32   |  80000  | RANKING(2-10)    | Remember The ''Knight Of Legend'' (2-10 Ranking) |
|  32   |  20   |  33   |  80000  | RANKING(DEMO)    | The Stars (Demo Ranking)                         |
|  33   |  21   |  34   |  80000  | ENDING(EASY)     | Shooting Stars (Easy Ending)                     |
|  34   |  22   |  35   |  80000  | ENDING(NORMAL)   | Silvery Light Of The Moon (Normal Ending)        |
| ..... | ..... | ..... | ....... | ...............  | ................................................ |
|  35   |  23   |  36   |  88000  | ENDING(HARD)     | Light Of Science (Hard Ending)                   |
|  36   |  24   |  37   |  88000  | ENDING(MANIAC)   | Love Dream (Maniac Ending)                       |
|  37   |  25   |  38   |  88000  | STAFF ROLL       | Stand Up Against Myself (Staff Roll)             |
|  38   |  26   |  39   |  88000  | OMAKE-1          | Omake 1                                          |
|  39   |  27   |  40   |  88000  | OMAKE-2          | Omake 2 Thunder Force AC                         |
|  40   |  28   |  41   |  88000  | OMAKE-3          | Omake 3                                          |
|  41   |  29   |  42   |  88000  | OMAKE-4          | Omake 4                                          |
|  42   |  2A   |  43   |  88000  | OMAKE-5          | Omake 5                                          |
|  43   |  2B   |  44   |  88000  | OMAKE-6          | Omake 6                                          |
|  44   |  2C   |  45   |  88000  | OMAKE-7          | Omake 7                                          |
|  45   |  2D   |  46   |  88000  | OMAKE-8          | Omake 8                                          |
|  46   |  2E   |  47   |  88000  | OMAKE-9          | Omake 9                                          |
|  47   |  2F   |  48   |  88000  | OMAKE-10         | Omake 10                                         |