### SoundDriver
Krisalis

| ID  | Track | Title                          | Loop |
| :-- | :---: | :----------------------------- | :--: |
| 01  |  --   | Stop Music                     | ---  |
| 5B  |  01   | Title Theme                    | yes  |
| 5A  |  02   | Map Screen                     |  no  |
| 03  |  03   | Woody Land 1 & 2 & Ending      | yes  |
| 4A  |  04   | Woody Land 3 & 4               | yes  |
| 85  |  05   | Mr Spider Attacks!             | yes  |
| 59  |  06   | Stage Clear                    |  no  |
| 38  |  07   | Adventure Park                 | yes  |
| 22  |  08   | The Living Room & Fowl Kitchen | yes  |
| 65  |  09   | In the Washbasin               | yes  |
| 9C  |  10   | Volcano Underpass              | yes  |
| 73  |  11   | Clouds                         | yes  |
| 89  |  12   | Mean Streets                   | yes  |
| AC  |  13   | Ice Scream & Frozen Nutz       | yes  |
| F2  |  14   | Boss Theme                     | yes  |
| 64  |  15   | Game Over                      |  no  |
| --- | ----- | ------------------------------ | ---  |
| --  |  16   | Ending*                        | yes  |
| --  |  17   | Ocean Logo*                    |  no  |
| --  |  18   | House*                         | yes  |
| --  |  19   | Little Clown*                  | yes  |
| --  |  20   | Ograoum Papas*                 | yes  |
| --  |  21   | Volcano Underpass 2*           | yes  |
| --  |  22   | Washbasin Boss*                | yes  |
| --- | ----- | ------------------------------ | ---  |
| --  |  23   | SEGA Logo*                     |  no  |
| --  |  24   | MSU Jingle*                    |  no  |

*custom added tracks


### RAM Locations

| Address  | Function   |
| :------- | :--------- |
| FF000C.b | Pause flag |
