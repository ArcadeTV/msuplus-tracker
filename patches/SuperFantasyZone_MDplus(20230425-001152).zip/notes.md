### SoundDriver
YMOIMO (Cube/Masaru Suzuki)

| ID  | BANK | Track | Title             | Loop |
| :-: | :--: | :---: | :---------------- | :--: |
| 06  |  02  |  01   | Opening           |  no  |
| 01  |  01  |  02   | Picnic            | yes  |
| 05  |  02  |  03   | Mango!            | yes  |
| 03  |  02  |  04   | Water Melody      | yes  |
| 04  |  02  |  05   | Good Evening!     | yes  |
| 02  |  02  |  06   | Fancy Promenard   | yes  |
| 08  |  01  |  07   | Vilily            | yes  |
| 02  |  01  |  08   | Fresh Melon       | yes  |
| 03  |  01  |  09   | Shop              | yes  |
| 05  |  01  |  10   | Boss              | yes  |
| 06  |  01  |  11   | Stage Clear       |  no  |
| 01  |  02  |  12   | Ya-Da-Ne          | yes  |
| 04  |  01  |  13   | Game Over         |  no  |
| 07  |  02  |  14   | Recollection      |  no  |
| 07  |  01  |  15   | Staff Roll        |  no  |
| 06  |  00  |  16   | Opa! Opa!         | yes  |
| 0A  |  00  |  17   | Keep On The Beat  | yes  |
| 0B  |  00  |  18   | Saari             | yes  |
| 02  |  00  |  19   | Prome             | yes  |
| 04  |  00  |  20   | Hot Snow          | yes  |
| 09  |  00  |  21   | Dreaming Tomorrow | yes  |
| 0C  |  00  |  22   | Don't Stop        | yes  |
| 05  |  00  |  23   | Shop (Old)        | yes  |
| 01  |  00  |  24   | Boss (Old)        | yes  |
| 08  |  00  |  25   | Stage Clear (Old) |  no  |
| 03  |  00  |  26   | Game Over (Old)   |  no  |
| --  |      |  27   | SEGA Logo*        |  no  |
| --  |      |  28   | MSU Jingle*       |  no  |

*custom added tracks


### ROM Locations

| Address | Function | original instruction   | Bytes |
| :------ | :------- | ---------------------- | :---: |
|         |          |                        |       |


### RAM Locations

| Address | Function |
| :------ | :------- |
|         |          |


### CHEATS

